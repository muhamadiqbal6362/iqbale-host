# glowing plants

A Pen created on CodePen.

Original URL: [https://codepen.io/Meysia-Amelia/pen/wBwLYNb](https://codepen.io/Meysia-Amelia/pen/wBwLYNb).

glowing plants